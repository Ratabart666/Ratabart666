Numerical Algorithms 0.2.4

This library have very strongs Algorithms
you should import as follow import Algoritmosnumericos as Alg
and if you wish to know  the funtions only write (help(Alg))
