Numerical Algorithms 0.1.3

This library have very strongs Algorithms
you should import as follow import Algoritmosnumericos as Alg
and if you wish to know  the funtions only write (help(Alg))
